<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "pizzeria_rest";
?>

