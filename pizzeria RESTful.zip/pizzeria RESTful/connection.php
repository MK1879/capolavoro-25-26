<?php
include 'config.php';
$conn = new mysqli($host, $user, $pass);
if ($conn->connect_error) {
    die("Connessione fallita");
}
$conn->query("CREATE DATABASE IF NOT EXISTS $dbname");
$conn->select_db($dbname);
$conn->query("
CREATE TABLE IF NOT EXISTS pizze (
    id_pizza INT(11) AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100),
    prezzo DECIMAL(5,2)
)
");
?>