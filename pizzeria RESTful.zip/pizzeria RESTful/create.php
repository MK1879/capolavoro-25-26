<?php

include 'connection.php';

$nome = $_POST['nome'];
$prezzo = $_POST['prezzo'];

$check = $conn->query("SELECT * FROM pizze WHERE nome='$nome'");

if($check->num_rows > 0){
    echo "errore_duplicato";
} else {
    $conn->query("INSERT INTO pizze(nome, prezzo) VALUES('$nome', '$prezzo')");
    echo "successo";
}

?>