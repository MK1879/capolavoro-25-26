<?php
include 'connection.php';
$nome = $_POST['nome'];
$conn->query("DELETE FROM pizze WHERE nome='$nome'");
echo "eliminato";
?>