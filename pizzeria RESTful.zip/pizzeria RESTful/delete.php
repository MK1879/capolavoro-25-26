<?php
include 'connection.php';
$id = $_POST['id'];
$conn->query("DELETE FROM pizze WHERE id_pizza='$id'");
echo "eliminato";
?>