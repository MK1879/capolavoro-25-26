<?php
    include 'connection.php';
    $id = $_POST['id'];
    $prezzo = $_POST['prezzo'];
    $conn->query("UPDATE pizze SET prezzo='$prezzo' WHERE id_pizza='$id'");
    echo "successo";
?>