window.onload = caricaPizza;
function caricaPizza() {
    fetch('read.php')
    .then(r => r.json())
    .then(data => 
        {
            let html = "";

            data.forEach(p => 
            {
                // Sostituito p.id con p.id_pizza
                html += `
                <tr onclick="selectRow(${p.id_pizza}, '${p.nome}', ${p.prezzo})">
                    <td>${p.id_pizza}</td>
                    <td>${p.nome}</td>
                    <td>${p.prezzo}</td>
                </tr>
                `;
            });
            document.getElementById("tabella").innerHTML = html;
        });
}

function selectRow(id_pizza, nome, prezzo) 
{
    document.getElementById("id").value = id_pizza;
    document.getElementById("nome").value = nome;
    document.getElementById("prezzo").value = prezzo;
}
function resetForm()
{
    document.getElementById("id").value = "";
    document.getElementById("nome").value = "";
    document.getElementById("prezzo").value = "";
}

function creaPizza() 
{
    let nome = document.getElementById("nome").value;
    let prezzo = document.getElementById("prezzo").value;
    let fd = new FormData();

    fd.append("nome", nome);
    fd.append("prezzo", prezzo);

    fetch("create.php", { method: "POST", body: fd })
    .then(() => caricaPizza());
}

function aggiornaPizza() 
{
    let id = document.getElementById("id").value;
    //Alert nel caso in cui non sia stata selezionata nessuna pizza   
    if(id == ""){
        alert("Seleziona prima una pizza dalla tabella");
        return;
    }

    let prezzo = document.getElementById("prezzo").value;
    let fd = new FormData();

    fd.append("id", id);
    fd.append("prezzo", prezzo);

    fetch("update.php", { method: "POST", body: fd })
    .then(() => caricaPizza());
    resetForm();
}

function eliminaPizza() 
{
    let id = document.getElementById("id").value;
    console.log(id);
    let fd = new FormData();

    fd.append("id", id);

    fetch("delete.php", { method: "POST", body: fd })
    .then(() => caricaPizza());
    resetForm();
}