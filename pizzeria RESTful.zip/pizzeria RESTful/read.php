<?php
include 'connection.php';
header('Content-Type: application/json');
$sql = "SELECT id_pizza, nome, prezzo FROM pizze";
$result = $conn->query($sql);
$pizze = [];

if ($result) {

    while ($row = $result->fetch_assoc()) {
        $pizze[] = $row;
    }

}

echo json_encode($pizze);
exit;

?>